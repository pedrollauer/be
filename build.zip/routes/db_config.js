module.exports={
	config:{
 
    "host" : "pedrolauer.mysql.uhserver.com",
    "port"     :  3306,
    "user" : "pedrolauer",
    "password" : "E2,71828e",
    "database" : "pedrolauer"
}
}

