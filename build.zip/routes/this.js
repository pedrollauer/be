var express = require('express');
var router = express.Router();
var cors = require('cors');

const db=require('./db_config');

const corsOptions={
	origin:'http://localhost:3001'
}
router.post('/',cors(corsOptions),async  function(req, res, next) {
  const mysql = require('mysql2/promise');
  const connection = await mysql.createConnection(db.config);
  let responseData=[];
try{
	let query = 'Select * from strings where language='+req.body.lang;
	const [strings,]=await connection.query(query);
	

	let stringData={};
	for(const string of strings){
	  stringData[string.string_name]=string.string_data;
	}
	
	
  query='Select * from Projetos';
  const [results,] = await connection.query(query);
	for(const result of results)
	{	
	  query='SELECT * FROM `proj_description` WHERE proj_id='+result.id+' and language='+req.body.lang;
		console.log(query);
	  const [description,]=await connection.query(query);

	  query='SELECT stack FROM `proj_stack` WHERE proj_id='+result.id;
		console.log(query);
	  const [stacks,]=await connection.query(query);
	  query='SELECT path FROM `Images` WHERE proj_id='+result.id;
	
	  const [images,]=await connection.query(query);
		console.log(images);
	  responseData.push({title:result.name,description:description[0].description,stacks:stacks,image:images[0].path});
	}
	console.log('ResponseData-->');

	
	stringData["projects"]=responseData;
	console.log(stringData);

  res.send(JSON.stringify(stringData));
}catch(e){
	console.log(e);
}finally{
	connection.end();
	console.log('Connection Successfuly ended.');
}
});

module.exports = router;
